#include "LIB/neslib.h"
#include "LIB/nesdoug.h"
#include "TILESETS/beep.h"
#include "TILESETS/collide.h"
#include "Sprites.h"


#pragma bss-name(push, "ZEROPAGE")

unsigned char pad1;
unsigned char pad2;
unsigned char collision;


#pragma bss-name(push, "BSS")

struct BoxGuy {
	unsigned char x;
	unsigned char y;
	unsigned char width;
	unsigned char height;
};

struct BoxGuy BoxGuy1 = {128,64,15,15};
struct BoxGuy BoxGuy2 = {128,168,15,15};
unsigned int collided = 0;




const unsigned char palette_bg[]={
0x0f, 0x0f, 0x0f, 0x30, // black, gray, lt gray, white
0,0,0,0,
0,0,0,0,
0,0,0,0
}; 


const unsigned char palette_sp[]={
0x0f, 0x0f, 0x0f, 0x28, // black, black, yellow
0x0f, 0x0f, 0x0f, 0x12, // black, black, blue
0,0,0,0,
0,0,0,0
};

// Shows title screen
void show_title() {
  // Disable Rendering
  ppu_off();

  // Set pallete to our title screen pallete
  pal_bg(palette_bg);
  
  // Unpack nametable into VRAM
  vram_adr(NAMETABLE_A);
  vram_unrle(beep);
  
  // Enable Rendering
  ppu_on_all();
  
  while(1) {
    ppu_wait_frame();
    
    if (pad_trigger(0)&PAD_START) break;
  }

}

// Shows level screen
void show_level() {
  // Disable Rendering
  ppu_off();

  // Set pallete to our level screen pallete
  pal_bg(palette_bg);
  
  // Unpack nametable into VRAM
  vram_adr(NAMETABLE_A);
  vram_unrle(collide);
  
  // Enable Rendering
  ppu_on_all();

}

void draw_sprites(void){
	// clear all sprites from sprite buffer
	oam_clear();
	
	// draw 2 metasprites
	oam_meta_spr(BoxGuy1.x, BoxGuy1.y, sprPlayer);
	
	oam_meta_spr(BoxGuy2.x, BoxGuy2.y, sprGhost);
}
	
	
	
void movement(void){
	if(pad1 & PAD_LEFT){
		BoxGuy1.x -= 1;
	}
	else if (pad1 & PAD_RIGHT){
		BoxGuy1.x += 1;
	}
	if(pad1 & PAD_UP){
		BoxGuy1.y -= 1;
	}
	else if (pad1 & PAD_DOWN){
		BoxGuy1.y += 1;
	}
	
	
	
	if(pad2 & PAD_LEFT){
		BoxGuy2.x -= 1;
	}
	else if (pad2 & PAD_RIGHT){
		BoxGuy2.x += 1;
	}
	if(pad2 & PAD_UP){
		BoxGuy2.y -= 1;
	}
	else if (pad2 & PAD_DOWN){
		BoxGuy2.y += 1;
	}
}	

void test_collision(void){
	collision = check_collision(&BoxGuy1, &BoxGuy2);
		
	// change the BG color, if sprites are touching
	if (collision){
	pal_col(0,0x30);
	}
	else{
		pal_col(0,0x0f);
	}

}

void main (void) {
	
	ppu_off(); // screen off
	
	// load the palettes
	pal_bg(palette_bg);
	pal_spr(palette_sp);

	// use the second set of tiles for sprites
	// both bg and sprite are set to 0 by default
	bank_spr(1);
	set_vram_buffer();
	
	song = 0;
	music_play(song);
	
	// turn on screen
	ppu_on_all(); 
	//music_play(song);

	
	//load title screen
	show_title();
	
	//when show_title breaks, load level
	show_level();
	music_play(song+1);

	//infinite loop
	
	while (1){
		ppu_wait_nmi(); // wait till beginning of the frame
		// the sprites are pushed from a buffer to the OAM during nmi
		set_music_speed(8);
		// clear all sprites from sprite buffer
		oam_clear();

		//set everything up
		pad1 = pad_poll(0);
		draw_sprites();
		movement();
		test_collision();
		}		
	}

	
	