
unsigned char song;
#define MAX_SONGS 2
enum {SONG_GAME, SONG_PAUSE};
void change_song(void);

// a 16x16 pixel metasprite

const unsigned char sprPlayer[]={
	  0,  0,0x00,0,
	  0,  8,0x10,0,
	  8,  0,0x00,0|OAM_FLIP_H,
	  8,  8,0x10,0|OAM_FLIP_H,
	128
};


const unsigned char sprGhost[]={
	  0,  0,0x00,1,
	  0,  8,0x10,1,
	  8,  0,0x00,1|OAM_FLIP_H,
	  8,  8,0x10,1|OAM_FLIP_H,
	128
};